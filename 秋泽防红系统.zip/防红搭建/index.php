<?php
session_start();
$xiaoyao = 'Website.txt'; 
$ok = 'ok.txt';
$xiaoyao1 = file_exists($xiaoyao)? file_get_contents($xiaoyao) : '';
$ok1 = file_exists($ok)? file_get_contents($ok) : '';
include 'config.php';

function getCustomerNumberByDomain($conn, $hd_old) {
    $parsed_url = parse_url($hd_old);
    $domain = isset($parsed_url['host']) ? $parsed_url['host'] : $hd_old;
    $sql = "SELECT customer FROM hd_records WHERE hd_old LIKE? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $like_domain = "%$domain%";
    $stmt->bind_param("s", $like_domain);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['customer'];
    } else {
        $sql = "SELECT MAX(CAST(SUBSTRING(customer, 3) AS UNSIGNED)) as max_num FROM hd_records WHERE customer LIKE '顾客%'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $maxNum = $row['max_num']? $row['max_num'] : 0;
        return "顾客" . ($maxNum + 1);
    }
}
function saveToDatabase($conn, $hd_old, $hd_new, $mode, $customer) {
    $sql = "INSERT INTO hd_records (hd_old, hd_new, mode, customer) VALUES (?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $hd_old, $hd_new, $mode, $customer);
    $stmt->execute();
    $stmt->close();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_to_db'])) {
    $hd_old = trim($_POST['hd_old']);
    $hd_new = trim($_POST['hd_new']);
    $mode = trim($_POST['mode']);
    $customer = trim($_POST['customer']);
    saveToDatabase($conn, $hd_old, $hd_new, $mode, $customer);
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_customer') {
    $hd_old = isset($_GET['hd_old']) ? trim($_GET['hd_old']) : '';
    header('Content-Type: application/json');
    echo json_encode(getCustomerNumberByDomain($conn, $hd_old));
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'generate_shorturl') {
    $url = trim($_POST['url']);
    $type = intval($_POST['type']);
    
    $encodedUrl = base64_encode($url);
    $encodedUrl = str_replace(['+', '/', '='], ['-', '_', ''], $encodedUrl);
    
    $shortUrl = ($type === 1) ? $xiaoyao1 . $encodedUrl : $ok1 . $encodedUrl;
    
    header('Content-Type: application/json');
    echo json_encode(['shortUrl' => $shortUrl]);
    exit;
}

$tx = 'Yao/eg/tx.txt';
$mz = 'Yao/eg/mz.txt';
$tx1 = file_exists($tx)? file_get_contents($tx) : '';
$mz1 = file_exists($mz)? file_get_contents($mz) : '';
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo"<title>秋泽防红系统</title>"; ?>
    <link rel="shortcut icon" href="https://avatars.githubusercontent.com/u/146703141" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
       .short-url-display{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;}
        *{margin:0;padding:0;box-sizing:border-box;font-family:MainFont,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;}
        :root{--primary-color:#C5C1FF;--hover-color:#C5C1FF;--text-color:#1a1a1a;--border-color:#e5e7eb;--background-color:#f0f0f0;}
        @font-face{font-family:'MainFont';src:url('/css/Font.woff2') format('woff2');font-weight:normal;font-style:normal;}
        body{min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px;color:var(--text-color);-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}
       .container{background:rgba(255,255,255,0.9);padding:40px;border-radius:24px;width:100%;max-width:500px;backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.1);}
       .form-header{text-align:center;margin-bottom:32px;}
       .form-header i{font-size:56px;background:linear-gradient(-225deg,#2CD8D5 0%,#C5C1FF 56%,#FFBAC3 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:20px;display:inline-block;animation:float 3s ease-in-out infinite;}
        @keyframes float{0%,100%{transform:translateY(0);}50%{transform:translateY(-10px);}}
       .form-header h1{font-size:28px;color:var(--text-color);margin-bottom:8px;font-weight:600;}
       .form-group{margin-bottom:24px;}
       .form-group label{display:block;margin-bottom:10px;color:var(--text-color);font-weight:500;font-size:15px;}
       .input-wrapper{position:relative;display:flex;align-items:center;}
       .input-wrapper i{position:absolute;left:16px;color:#6b7280;font-size:18px;transition:all 0.3s ease;}
        #selectArrow{position:absolute;right:16px;left:auto;color:#6b7280;font-size:14px;transition:transform 0.3s ease;pointer-events:none;}
        select:focus~#selectArrow{transform:rotate(180deg);}
        input[type="url"],select{width:100%;padding:16px 16px 16px 48px;border:2px solid var(--border-color);border-radius:16px;font-size:16px;transition:all 0.3s ease;background:#fafafa;appearance:none;cursor:pointer;}
        input[type="url"]:focus,select:focus{border-color:var(--primary-color);outline:none;background:white;}
        input[type="url"]:focus+i,select:focus+i{color:var(--primary-color);}
        input[type="button"]{width:100%;padding:16px;background:linear-gradient(-225deg,#2CD8D5 0%,#C5C1FF 56%,#FFBAC3 100%);color:white;border:none;border-radius:16px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.3s ease;position:relative;overflow:hidden;}
        input[type="button"]:hover{transform:translateY(-2px);}
        input[type="button"]:active{transform:translateY(0);}
        #resultContainer{margin-top:20px;text-align:center;}
        #shortUrlDisplay{padding:16px;background:#fafafa;border:2px solid var(--border-color);border-radius:16px;font-size:14px;color:#C5C1FF;cursor:pointer;transition:all 0.3s ease;}
        @media (max-width: 480px) {.container{padding:30px 20px;}.form-header i{font-size:48px;}.form-header h1{font-size:24px;}}
    </style>
</head>
<body>
    <div class="container">
        <div class="form-header">
            <i class="fas fa-link"></i>
            <h1>秋泽防红系统</h1>
        </div>
        <form id="signup-form" method="post">
            <div class="form-group">
                <div class="input-wrapper">
                    <input type="url" name="targetUrl" id="targetUrl" placeholder="需要生成的链接">
                    <i class="fas fa-link"></i>
                </div>
            </div>
            <div class="form-group">
                <div class="input-wrapper">
                    <select name="type" id="type" required>
                        <option value="1">秋泽|Wechat </option>
                        <option value="2">秋泽|alipay</option>
                    </select>
                    <i class="fas fa-cog"></i>
                    <i class="fas fa-chevron-down" id="selectArrow"></i>
                </div>
            </div>
            <input type="button" value="生成" id="generateButton" onclick="getUrl()" />
        </form>
        <div id="resultContainer"></div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function getUrl() {
            const targetUrl = document.getElementById('targetUrl').value;
            const type = document.getElementById('type').value;
            const agree = true; 
            const generateButton = document.getElementById('generateButton');

            if (!targetUrl) {
                alert('请输入要生成的链接');
                document.getElementById('targetUrl').blur(); 
                return;
            }

            generateButton.value = "正在生成";
            generateButton.disabled = true;

            document.getElementById('resultContainer').innerHTML = "";

            $.post("add.php", {
                'url': targetUrl,
                'agree': agree
            }, function (data, status) {
                if (data.includes('请联系秋泽')) {
                    alert('请联系秋泽tgQZNB886688添加白名单');
                    document.getElementById('resultContainer').innerHTML = 
                        "<div class='short-url-display' id='shortUrlDisplay' onclick='window.location.href=\"tg://resolve?domain=@xshczc\"'>请联系秋泽tgQZNB886688 添加白名单</div>";
                } else if (data === '链接仅支持HTTP/HTTPS协议') {
                    alert('链接仅支持HTTP/HTTPS协议');
                } else if (data === '请先同意并勾选生成服务使用守则') {
                    alert('请先同意并勾选生成服务使用守则');
                } else if (data === 'success') {
                    const type = $('#type').val();
            
                    // 新增请求获取完整短链接
                    $.post("<?php echo basename(__FILE__); ?>", {
                        action: 'generate_shorturl',
                        url: targetUrl,
                        type: type
                    }, function(response) {
                        const shortUrl = response.shortUrl;
                
                        // 显示短链接
                        document.getElementById('resultContainer').innerHTML =
                            "<div class='short-url-display' id='shortUrlDisplay' onclick='huaidanCopyShortLink(\"" + shortUrl + "\")'>" + shortUrl + "</div>";
                        // 保存记录
                        setTimeout(() => {
                            $.get("<?php echo basename(__FILE__); ?>?action=get_customer&hd_old=" + encodeURIComponent(targetUrl), function(customer) {
                                    $.post("<?php echo basename(__FILE__); ?>", {
                                        'save_to_db': true,
                                        'hd_old': targetUrl,
                                        'hd_new': shortUrl,
                                        'mode': $('#type option:selected').text(),
                                        'customer': customer
                                    });
                                });
                        }, 500);
                    }, 'json');
                } else {
                    alert('系统错误，请稍后再试');
                }
                setTimeout(() => {
                    generateButton.value = "生成";
                    generateButton.disabled = false;
                }, 509);
            });
        }

        function huaidanCopyShortLink(url) {
            const textarea = document.createElement('textarea');
            textarea.value = url;
            textarea.style.position = 'fixed';
            textarea.style.opacity = 0;
            document.body.appendChild(textarea);
            textarea.select();
            try {
                const successful = document.execCommand('copy');
                const msg = successful? '链接已成功复制到剪贴板' : '复制链接失败，请重试';
                alert(msg);
            } catch (err) {
                alert('复制链接失败，请重试');
            }
            document.body.removeChild(textarea);
        }
    </script>
</body>
</html>