<?php
$db_host = 'localhost';
$db_name = 'fhqz'; // 假设所有表在同一数据库
$db_user = 'fhqz';
$db_pass = 'fhqz';

$pdo = new PDO("mysql:host={$db_host};dbname={$db_name}", $db_user, $db_pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
?>
