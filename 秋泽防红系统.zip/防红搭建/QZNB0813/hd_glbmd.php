<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 处理 AJAX 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['action'])) {
    header('Content-Type: application/json');

    // 处理删除白名单
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $main_domain = trim($_POST['main_domain']);
        $delete_sql = "DELETE FROM huaidanbmd WHERE main_domain = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("s", $main_domain);
        if ($stmt->execute()) {
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        $stmt->close();
        exit;
    }

    // 处理列表请求
    if (isset($_GET['action']) && $_GET['action'] === 'list') {
        $sql = "SELECT main_domain FROM huaidanbmd";
        $result = $conn->query($sql);
        $domains = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $domains[] = ['main_domain' => $row['main_domain']];
            }
        }
        echo json_encode([
            'code' => 0,
            'msg' => '',
            'count' => count($domains),
            'data' => $domains
        ]);
        $conn->close();
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>白名单管理 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">
         <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            padding: 20px;
        }
        .layui-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="layui-container">
    <div class="layui-card">
        <div class="layui-card-header">白名单列表 (欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>)</div>
        <div class="layui-card-body">
            <table class="layui-table" lay-data="{url:'admin.php?action=list', page:true, id:'domainTable'}" lay-filter="domainTable">
                <thead>
                    <tr>
                        <th lay-data="{field:'main_domain', width:300}">已经添加的</th>
                        <th lay-data="{fixed:'right', width:150, align:'center', toolbar:'#barDemo'}">操作</th>
                    </tr>
                </thead>
            </table>
            <script type="text/html" id="barDemo">
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="delete">删除</a>
            </script>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['table', 'layer'], function(){
    var table = layui.table;
    var layer = layui.layer;
    var $ = layui.$;

    // 删除域名
    table.on('tool(domainTable)', function(obj){
        var data = obj.data;
        if (obj.event === 'delete') {
            layer.confirm('确定删除域名 ' + data.main_domain + ' 吗？', {
                btn: ['确定', '取消']
            }, function(){
                $.ajax({
                    url: 'admin.php',
                    type: 'POST',
                    data: {
                        action: 'delete',
                        main_domain: data.main_domain
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.code === 0) {
                            layer.msg(res.msg, {icon: 1});
                            obj.del();
                        } else {
                            layer.msg(res.msg, {icon: 2});
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        layer.msg('请求失败: ' + textStatus, {icon: 2});
                        console.error('删除请求错误:', textStatus, errorThrown, jqXHR.responseText);
                    }
                });
            });
        }
    });
});
</script>
</body>
</html>
