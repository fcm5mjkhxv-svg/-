
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>联系</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="/css/1layui.css"/>
<link href="/css/yongheng.css" rel="stylesheet">
<script type="text/javascript" src="/css/yongheng.js"></script>
<style>
    /* 您的CSS代码 */
    .swal2-title {
        font-weight: normal !important; 
    }
    
    .swal2-popup {
        border-radius: 15px; 
    }

    .custom-icon {
        display: block;
        margin: 0 auto 10px; 
        width: 80px;
        height: 80px;
        border-radius: 10px; 
        object-fit: cover;
    }
</style>

<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    Swal.fire({
        html: `
            
<img src="http://q2.qlogo.cn/headimg_dl?dst_uin=3858125122&spec=640" class="custom-icon">
            
<h2 style="margin: 0;">秋泽</h2> 
            
<p>TG@QZNB886688
<br>上台记得改密码
<br>海鸥39980618 接码搭建假链接假客服淘口令接HX回收各大礼品卡沃尔玛85卡包8 E卡永辉等统统回8 微信群引导 京东卡扣</p>
        `,
 showCancelButton: true,
 confirmButtonText: '修改密码',
 cancelButtonText: '关闭',
 customClass: {
 popup: 'rounded-popup'
                },
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                },
                preConfirm: () => {
                    const targetUrl = 'edit_info.php';
                    window.location.href = targetUrl;
        },
    });
});
</script>
  
<style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @font-face {
            font-family: 'MainFont';
            src: url('/assets/static/font/main/main.woff2') format('woff2');
            font-weight: normal;
            font-style: normal;
        }

        body {
            font-family: MainFont, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background:rgb(255, 255, 255);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(-225deg, #2CD8D5 0%, #C5C1FF 56%, #FFBAC3 100%););
            padding: 30px;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 20px;
            position: relative;
            z-index: 1;
        }

        .avatar {
            width: 100px;
            height: 100px;
            border-radius: 20px;
            border: 3px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .avatar:hover {
            transform: scale(1.05);
            border-color: white;
        }

        .info h1 {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .info .title {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 12px;
        }

        .contact {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .contact-btn {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .contact-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .content {
            padding: 30px;
        }

        .section {
            margin-bottom: 24px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title i {
            color: #C5C1FF;
        }

        .skill-list {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .skill-tag {
            padding: 8px 16px;
            background:rgb(231, 230, 250);
            color: #C5C1FF;
            border-radius: 20px;
            font-size: 14px;
        }

        .achievement-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 20px;
        }

        .achievement-item {
            background: #f9fafb;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }

        .achievement-item i {
            font-size: 24px;
            color: #C5C1FF;
            margin-bottom: 12px;
        }

        .achievement-item .number {
            font-size: 24px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 4px;
        }

        .achievement-item .label {
            font-size: 14px;
            color: #6b7280;
        }

        @media (max-width: 640px) {
            .profile {
                flex-direction: column;
                text-align: center;
            }

            .contact {
                justify-content: center;
            }

            .achievement-list {
                grid-template-columns: 1fr;
            }
        }
    </style>

</head>

<body>
    <div class="container">
        <div class="header">
            <div class="profile">
                <img src="https://q2.qlogo.cn/headimg_dl?dst_uin=3858125122&spec=100" alt=" 秋泽 " class="avatar">
                <div class="info">
                    <h1>  秋泽防红  </h1>
                    <div class="title">定制源码 | HX代开</div>
                    <div class="contact">
                        <a href="https://t.me/@QZNB886688"
                            class="contact-btn" target="_blank">
                            <i class="fab fa-telegram"></i>
                            tg@QZNB886688
                        </a>
                        <a href="https://ti.qq.com/open_qq/index2.html?url=mqqapi%3A%2F%2Fuserprofile%2Ffriend_profile_card%3Fsrc_type%3Dweb%26version%3D1.0%26source%3D2%26uin%3D3858125122"
                            class="contact-btn" target="_blank">
                            <i class="fab fa-qq"></i>
                            3858125122
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-star"></i>
                     秋泽 
                </div>
                <div class="skill-list">
                    <div class="skill-tag">入金渠道</div>
                    <br>
                    <div class="skill-tag"> 网站开发 </div><br>
                </div>
            </div>

            <div class="section">
                <div class="section-title">
                    <i class="fas fa-trophy"></i>
                    工作成就
                </div>
                <div class="achievement-list">
                    <div class="achievement-item">
                        <i class="fas fa-project-diagram"></i>
                        <div class="number">5+</div>
                        <div class="label">成功项目</div>
           
           
           
           
                    </div>
                </div>
            </div>

            <div class="section">
                <div class="section-title">
                    <i class="fas fa-check-circle"></i>
                    服务优势
                </div>
                <div class="skill-list">
                    <div class="skill-tag">定制化解决方案</div>
                    <div class="skill-tag">7*24小时技术支持</div>
                    <div class="skill-tag">安全性保障</div>
                    <div class="skill-tag">快速响应</div>
                    <div class="skill-tag">一对一服务</div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>