<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

// 确保文件路径正确
$tx = 'eg/tx.txt';
$mz = 'eg/mz.txt';

// 检查文件是否存在
if (file_exists($tx)) {
    // 读取文件内容
    $tx1 = file_get_contents($tx);
}
if (file_exists($mz)) {
    // 读取文件内容
    $mz1 = file_get_contents($mz);
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<title><?php echo $mz1?>后台管理系统</title>
<link rel="stylesheet" type="text/css" href="static/LightYearv5/css/materialdesignicons.min.css">
<link rel="stylesheet" type="text/css" href="static/LightYearv5/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="static/LightYearv5/css/animate.min.css">
<link rel="stylesheet" type="text/css" href="static/LightYearv5/css/multitabs.min.css">
<link rel="stylesheet" type="text/css" href="static/LightYearv5/css/style.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
      * {
            font-family: MainFont, sans-serif;
        }

        @font-face {
            font-family: 'MainFont';
            src: url('/css/Font.woff2') format('woff2');
            font-weight: normal;
            font-style: normal;
        }

        .nav-drawer .mdi {
            font-size: 1.1rem;
            width: 1.2em;
            text-align: center;
            margin-right: 0.5rem;
        }
    .nav-drawer .fa-solid,
    .nav-drawer .fa-regular,
    .nav-drawer .fa-brands {
        font-size: 1.1rem;
        width: 1.2em;
        text-align: center;
        margin-right: 0.5rem;
        transform: translateY(6px);
    }
    
    .nav-drawer a:hover i {
        transform: scale(1.1);
        transition: transform 0.2s ease;
    }
    
    .fa-beat-fade,
    .fa-bounce,
    .fa-flip,
    .fa-fade,
    .fa-shake {
        animation-duration: 2s;
    }
          
       /* TG@xshczc开发 */
    .fa-heartbeat{
        color: #DC143C;   }

        
    /* 首页仪表盘 */
    .fa-gauge-high { color: #2196F3; }
    
    /* 联系小烁 */
    .fa-paper-plane { color: #00BCD4; }
    
    /* 工具合集 */
    .fa-screwdriver-wrench { color: #FF9800; }
    
    /* 防洪and短链接 */
    .fa-shield-halved { color: #673AB7; }
    
    /* 确保 btn-link 类不会添加下划线 */
    .btn-link {
        text-decoration: none !important;
    }
    
    .btn-link:hover,
    .btn-link:focus,
    .btn-link:active {
        text-decoration: none !important;
    }
</style>
</head>
<body class="lyear-index">
<div class="lyear-layout-web">
  <div class="lyear-layout-container">
    <!--左侧导航-->
    <aside class="lyear-layout-sidebar">
      <!-- 后台测试logo -->
      <div id="logo" class="sidebar-header">
        <center style="height:40px; margin:15px;">
     <img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo $tx1?>&spec=100" style="border-radius:30%; width:48px; height:63x;">
        <cite>
            <?php echo $mz1?>防红
            <i class="fa-solid fa-circle-check" style="color: #C5C1FF; margin-left: 5px; font-size: 0.9em; vertical-align: middle;"></i>
        </cite>
        </center>
      </div>
      <div class="lyear-layout-sidebar-info lyear-scroll">
        <nav class="sidebar-main">
          <ul class="nav-drawer">
            <li class="nav-item active">
             <a class="multitabs" href="view.php" id="default-page">
                <i class="fa-solid fa-gauge-high"></i>
               <span>后台首页</span>
              </a>
                   </a>
                         <li class="nav-item">
                <a  href="/">
                  <i class="fa-solid fa-heartbeat"></i>
                  <span>  点击进入防红页面  </span>
                </a>
            </li>
            <li class="nav-item nav-item-has-subnav">
            <a href="javascript:void(0)"><i class="fa-solid fa-screwdriver-wrench"></i> <span>白名单管理</span></a>
            <ul class="nav nav-subnav">
            <li> <a class="multitabs" href="hd_tjbmd.php" target="_blank">添加白名单</a> </li>
            <li> <a class="multitabs" href="hd_glbmd.php" target="_blank">管理白名单</a> </li>
            <li> <a class="multitabs" href="hd_kgbmd.php" target="_blank">开关白名单</a> </li>
            </ul>
            </li>
            <li class="nav-item nav-item-has-subnav">
            <a href="javascript:void(0)"><i class="fa-solid fa-shield-halved"></i> <span>短链管理</span></a>
            <ul class="nav nav-subnav">
            <li> <a class="multitabs" href="hd_jilu.php" target="_blank">记录查看</a> </li>
            <li> <a class="multitabs" href="hd_jk.php" target="_blank"> 微信接口修改 </a> </li>
                 <li> <a class="multitabs" href="Zfbjk.php" target="_blank"> 支付宝接口修改 </a> </li> 
            </ul>
            </li>
            <li class="nav-item nav-item-has-subnav">
            <a href="javascript:void(0)">
                <i class="fa-solid fa-comments" style="color: #4CAF50;"></i>
                <span>账号管理</span>
            </a>
            <ul class="nav nav-subnav">
            <li> <a class="multitabs" href="hd_user.php" target="_blank">修改账号</a> </li>
            </ul>
            </li>
          </ul>
        </nav>
             
      
<div class="ps__rail-x" style="left: 0px; bottom: 2px;">
<div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div>
<div class="ps__rail-y" style="top: 0px; right: 2px;">
<div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
      
    </aside>
    <!--End 左侧导航-->
    <!--头部信息-->
    <header class="lyear-layout-header">
      <nav class="navbar">
        <div class="navbar-left">
          <div class="lyear-aside-toggler">
            <span class="lyear-toggler-bar"></span>
            <span class="lyear-toggler-bar"></span>
            <span class="lyear-toggler-bar"></span>
          </div>
        </div>
        <ul class="navbar-right d-flex align-items-center">
          <!--个人头像内容-->
          <li class="dropdown">
            <a href="javascript:void(0)" data-bs-toggle="dropdown" class="dropdown-toggle">
           <img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo $tx1?>&spec=100" style="border-radius:30%; width:48px; height:63x;">
              <span style="margin-left: 10px;"><?php echo $mz1?>防红</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="dropdown-item" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>login.php">
                  <i class="mdi mdi-logout-variant"></i>
                  <span>退出登录</span>
                </a>
                <a class="multitabs dropdown-item" data-url="hd_user.php" href="javascript:void(0)">
                  <i class="mdi mdi-account"></i>
                  <span>修改密码</span>
                  </a>
                  
                  
                         <a class="multitabs dropdown-item" data-url="admin.php"
                  href="javascript:void(0)">
                  <i class="mdi mdi-account"></i>
                  <span> 总管理 </span>
                </a>
              </li>
            </ul>
          </li>
          <!--End 个人头像内容-->
        </ul>
      </nav>
    </header>
    <!--End 头部信息-->
    <!--页面主要内容-->
    <main class="lyear-layout-content">
      <div id="iframe-content"></div>
    </main>
    <!--End 页面主要内容-->
  </div>
</div>

<script type="text/javascript" src="static/LightYearv5/js/jquery.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/popper.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/bootstrap.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/multitabs.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="static/LightYearv5/js/index.min.js"></script>


<script>
    layui.use(['index', 'introJs'], function () {
        var $ = layui.jquery;
        var index = layui.index;
        var introJs = layui.introJs;

        // 默认加载主页
        index.loadHome({
            menuPath: 'view.php',
            menuName: '<i class="layui-icon layui-icon-home"></i>'
        });
    
        // 开始指引
        $('#otherIntroBtn1').click(function () {
            introJs().start();
        });
    });
</script>

</body>
</html>