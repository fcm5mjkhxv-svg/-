<?php
session_start(); // 启动会话
require_once 'config.php'; // 引入数据库配置

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        $sql = "SELECT * FROM login WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        $hashed_password = md5($password);
        if ($user && $hashed_password === $user['password']) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit;
        } else {
            $error = "用户名或密码错误";
        }
    } else {
        $error = "请填写用户名和密码";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>登录 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">
         <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
       .login-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
       .layui-form-item.layui-input-block {
            margin-left: 100px;
        }
       .layui-form-label {
            width: 80px;
        }
    </style>
</head>
<body>
<div class="login-box">
    <div class="layui-card">
        <div class="layui-card-header" style="text-align: center; font-size: 20px;">后台登录</div>
        <div class="layui-card-body">
            <form class="layui-form" method="POST" action="">
                <div class="layui-form-item">
                    <label class="layui-form-label">用户名</label>
                    <div class="layui-input-block">
                        <input type="text" name="username" required lay-verify="required" placeholder="请输入用户名" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">密码</label>
                    <div class="layui-input-block">
                        <input type="password" name="password" required lay-verify="required" placeholder="请输入密码" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="login">立即登录</button>
                    </div>
                </div>
                <?php if (isset($error)): ?>
                    <div class="layui-form-item">
                        <div class="layui-input-block" style="color: red; text-align: center;"><?php echo $error; ?></div>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['form', 'layer'], function(){
    var form = layui.form;
    var layer = layui.layer;

    form.on('submit(login)', function(data){
        return true;
    });
});
</script>
</body>
</html>
