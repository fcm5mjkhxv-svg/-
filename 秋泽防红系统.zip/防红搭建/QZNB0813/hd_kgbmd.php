<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 处理 AJAX 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $status = ($action === 'enable_whitelist') ? '1' : '0'; // 1 为启用，0 为关闭

    $update_sql = "UPDATE huaidansetting SET kq_domain = ? WHERE gb_domain = 'whitelist_enabled'";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("s", $status);
    if ($stmt->execute()) {
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
    } else {
        echo json_encode(['code' => 1, 'msg' => '操作失败']);
    }
    $stmt->close();
    $conn->close();
    exit;
}

// 获取白名单开关状态
$status = '0'; // 默认关闭
$sql = "SELECT kq_domain FROM huaidansetting WHERE gb_domain = 'whitelist_enabled'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $status = $result->fetch_assoc()['kq_domain'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>白名单开关 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">
         <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .layui-card {
            width: 100%;
            max-width: 400px;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
    </style>
</head>
<body>
<div class="layui-card">
    <div class="layui-card-header">白名单开关 (欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>)</div>
    <div class="layui-card-body">
        <div class="button-group">
            <button type="button" class="layui-btn layui-btn-normal" id="enableWhitelist" <?php echo $status === '1' ? 'disabled' : ''; ?>>启用白名单</button>
            <button type="button" class="layui-btn layui-btn-warm" id="disableWhitelist" <?php echo $status === '0' ? 'disabled' : ''; ?>>关闭白名单</button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['layer'], function(){
    var layer = layui.layer;
    var $ = layui.$;

    // 启用白名单
    $('#enableWhitelist').click(function(){
        $.post('hd_kgbmd.php', {action: 'enable_whitelist'}, function(res) {
            if (res.code === 0) {
                layer.msg('白名单已启用', {icon: 1});
                $('#enableWhitelist').addClass('layui-btn-disabled').prop('disabled', true);
                $('#disableWhitelist').removeClass('layui-btn-disabled').prop('disabled', false);
            } else {
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
    });

    // 关闭白名单
    $('#disableWhitelist').click(function(){
        $.post('hd_kgbmd.php', {action: 'disable_whitelist'}, function(res) {
            if (res.code === 0) {
                layer.msg('白名单已关闭', {icon: 1});
                $('#disableWhitelist').addClass('layui-btn-disabled').prop('disabled', true);
                $('#enableWhitelist').removeClass('layui-btn-disabled').prop('disabled', false);
            } else {
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
    });
});
</script>
</body>
</html>
