<?php
$LoginEdUserName = $_COOKIE['h_userName'];
$LoginEdPassWord = $_COOKIE['h_passWord'];

$rs88 = $db->get_one("select * from `h_kefu_config` where h_admin = '{$LoginEdUserName}' and h_pass = '{$LoginEdPassWord}' LIMIT 1");
if (!$rs88) {

    // 注意这里，我们直接使用变量而不是再次嵌入PHP标签
    HintAndTurnTopFrame("欢迎登录秋泽后台管理系统！", "http://" . $_SERVER['HTTP_HOST']);
    exit();
}

$rs99 = $db->get_one("select * from `h_kefu_login` where h_user = '{$LoginEdUserName}' and h_ip = '" . getUserIP() . "'");
if (!$rs99) {

    // 同样，这里也直接使用变量
    HintAndTurnTopFrame("您未登录成功，请您重新登录！", "http://" . $_SERVER['HTTP_HOST']);
    exit();
}
?>
