<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php"); // 未登录则跳转到登录页面
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 获取当前用户信息
$username = $_SESSION['username'];
$sql = "SELECT * FROM login WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// 处理表单提交（修改用户名和密码）
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = trim($_POST['new_username']);
    $new_password = trim($_POST['new_password']);

    if (!empty($new_username) && !empty($new_password)) {
        $hashed_password = md5($new_password); // 将新密码转为 MD5
        $sql = "UPDATE login SET username = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $new_username, $hashed_password, $user['id']);
        $stmt->execute();
        $stmt->close();

        // 更新会话中的用户名
        $_SESSION['username'] = $new_username;
        $success = "账号和密码已成功更新！";
        
        // 刷新用户信息
        $sql = "SELECT * FROM login WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $new_username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
    } else {
        $error = "请填写新用户名和新密码";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>修改账号 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">     <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .edit-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .layui-form-item .layui-input-block {
            margin-left: 100px;
        }
        .layui-form-label {
            width: 80px;
        }
    </style>
</head>
<body>
<div class="edit-box">
    <div class="layui-card">
        <div class="layui-card-header" style="text-align: center; font-size: 20px;">修改账号信息</div>
        <div class="layui-card-body">
            <form class="layui-form" method="POST" action="">
                <div class="layui-form-item">
                    <label class="layui-form-label">当前用户名</label>
                    <div class="layui-input-block">
                        <input type="text" value="<?php echo htmlspecialchars($user['username']); ?>" class="layui-input" disabled>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">新用户名</label>
                    <div class="layui-input-block">
                        <input type="text" name="new_username" required lay-verify="required" placeholder="请输入新用户名" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">新密码</label>
                    <div class="layui-input-block">
                        <input type="password" name="new_password" required lay-verify="required" placeholder="请输入新密码" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="edit">保存修改</button>
                    </div>
                </div>
                <?php if (isset($success)): ?>
                    <div class="layui-form-item">
                        <div class="layui-input-block" style="color: green; text-align: center;"><?php echo $success; ?></div>
                    </div>
                <?php endif; ?>
                <?php if (isset($error)): ?>
                    <div class="layui-form-item">
                        <div class="layui-input-block" style="color: red; text-align: center;"><?php echo $error; ?></div>
                    </div>
                <?php endif; ?>
            </form>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <a href="logout.php" class="layui-btn layui-btn-danger layui-btn-fluid">退出登录</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['form', 'layer'], function(){
    var form = layui.form;
    var layer = layui.layer;

    form.on('submit(edit)', function(data){
        return true; // 提交表单
    });
});
</script>
</body>
</html>
