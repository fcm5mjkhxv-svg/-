<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

require_once 'config.php';

if (isset($_GET['action']) && $_GET['action'] === 'list') {
    $records = [];
    if (isset($_GET['domain']) && !empty(trim($_GET['domain']))) {
        $domain = trim($_GET['domain']);
        $sql = "SELECT id, hd_old, hd_new, mode, customer FROM hd_records WHERE hd_old LIKE ? OR hd_new LIKE ?";
        $stmt = $conn->prepare($sql);
        $like_domain = "%$domain%";
        $stmt->bind_param("ss", $like_domain, $like_domain);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $records[] = [
                'id' => $row['id'],
                'hd_old' => $row['hd_old'],
                'hd_new' => $row['hd_new'],
                'mode' => $row['mode'],
                'customer' => $row['customer']
            ];
        }
        $stmt->close();
    } else {
        $sql = "SELECT id, hd_old, hd_new, mode, customer FROM hd_records";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $records[] = [
                'id' => $row['id'],
                'hd_old' => $row['hd_old'],
                'hd_new' => $row['hd_new'],
                'mode' => $row['mode'],
                'customer' => $row['customer']
            ];
        }
    }
    echo json_encode([
        'code' => 0,
        'msg' => '',
        'count' => count($records),
        'data' => $records
    ]);
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>记录管理 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">
         <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            padding: 20px;
        }
        .layui-card {
            margin-bottom: 20px;
        }
        .search-box {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="layui-container">
    <div class="search-box">
        <div class="layui-form">
            <div class="layui-inline">
                <input type="text" name="domain" id="searchDomain" placeholder="请输入域名（支持输入或防红域名）" autocomplete="off" class="layui-input">
            </div>
            <div class="layui-inline">
                <button class="layui-btn" id="searchBtn">搜索</button>
            </div>
        </div>
    </div>
    <div class="layui-card">
        <div class="layui-card-header">防红记录管理 (欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>)</div>
        <div class="layui-card-body">
            <table class="layui-table" lay-data="{url:'hd_jilu.php?action=list', page:true, id:'recordTable'}" lay-filter="recordTable">
                <thead>
                    <tr>
                        <th lay-data="{field:'id', width:80}">ID</th>
                        <th lay-data="{field:'hd_old', width:250}">输入域名</th>
                        <th lay-data="{field:'hd_new', width:250}">防红域名</th>
                        <th lay-data="{field:'mode', width:150}">模式</th>
                        <th lay-data="{field:'customer', width:150}">顾客编号</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['table', 'form'], function(){
    var table = layui.table;
    var form = layui.form;

    document.getElementById('searchBtn').onclick = function() {
        var domain = document.getElementById('searchDomain').value;
        table.reload('recordTable', {
            url: 'hd_jilu.php?action=list&domain=' + encodeURIComponent(domain),
            page: { curr: 1 }
        });
    };

    document.getElementById('searchDomain').onkeydown = function(event) {
        if (event.key === 'Enter') {
            document.getElementById('searchBtn').click();
        }
    };
});
</script>
</body>
</html>
