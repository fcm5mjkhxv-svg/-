<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 处理 AJAX 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    header('Content-Type: application/json');
    $main_domain = trim($_POST['main_domain']);
    if (!empty($main_domain)) {
        $check_sql = "SELECT COUNT(*) FROM huaidanbmd WHERE main_domain = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("s", $main_domain);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            echo json_encode(['code' => 1, 'msg' => '该域名已存在']);
        } else {
            $insert_sql = "INSERT INTO huaidanbmd (main_domain) VALUES (?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("s", $main_domain);
            if ($stmt->execute()) {
                echo json_encode(['code' => 0, 'msg' => '添加成功']);
            } else {
                echo json_encode(['code' => 1, 'msg' => '添加失败']);
            }
            $stmt->close();
        }
    } else {
        echo json_encode(['code' => 1, 'msg' => '域名不能为空']);
    }
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>添加白名单 - 秋泽网络后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">     <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            padding: 20px;
        }
        .layui-card {
            margin-bottom: 20px;
        }
        .button-group {
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: flex-start;
        }
    </style>
</head>
<body>
<div class="layui-container">
    <div class="layui-card">
        <div class="layui-card-header">添加白名单主域名 (欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>)</div>
        <div class="layui-card-body">
            <form class="layui-form" id="addForm">
                <div class="layui-form-item">
                    <label class="layui-form-label">主域名</label>
                    <div class="layui-input-block">
                        <input type="text" name="main_domain" required lay-verify="required" placeholder="输入域名" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <div class="button-group">
                            <button class="layui-btn" lay-submit lay-filter="addDomain">立即添加</button>
                            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['form', 'layer'], function(){
    var form = layui.form;
    var layer = layui.layer;
    var $ = layui.$;

    // 添加域名
    form.on('submit(addDomain)', function(data){
        $.ajax({
            url: 'hd_tjbmd.php',
            type: 'POST',
            data: {
                action: 'add',
                main_domain: data.field.main_domain
            },
            dataType: 'json',
            success: function(res) {
                if (res.code === 0) {
                    layer.msg(res.msg, {icon: 1});
                    $('#addForm')[0].reset();
                } else {
                    layer.msg(res.msg, {icon: 2});
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                layer.msg('请求失败: ' + textStatus, {icon: 2});
                console.error('添加请求错误:', textStatus, errorThrown, jqXHR.responseText);
            }
        });
        return false;
    });
});
</script>
</body>
</html>
