<?php
session_start(); // 启动会话

// 检查是否登录
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 处理 AJAX 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['action'])) {
    header('Content-Type: application/json'); // 确保返回 JSON

    // 处理添加白名单
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $main_domain = trim($_POST['main_domain']);
        if (!empty($main_domain)) {
            $check_sql = "SELECT COUNT(*) FROM huaidanbmd WHERE main_domain = ?";
            $stmt = $conn->prepare($check_sql);
            $stmt->bind_param("s", $main_domain);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();

            if ($count > 0) {
                echo json_encode(['code' => 1, 'msg' => '该域名已存在']);
            } else {
                $insert_sql = "INSERT INTO huaidanbmd (main_domain) VALUES (?)";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bind_param("s", $main_domain);
                if ($stmt->execute()) {
                    echo json_encode(['code' => 0, 'msg' => '添加成功']);
                } else {
                    echo json_encode(['code' => 1, 'msg' => '添加失败']);
                }
                $stmt->close();
            }
        } else {
            echo json_encode(['code' => 1, 'msg' => '域名不能为空']);
        }
        exit;
    }

    // 处理删除白名单
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $main_domain = trim($_POST['main_domain']);
        $delete_sql = "DELETE FROM huaidanbmd WHERE main_domain = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("s", $main_domain);
        if ($stmt->execute()) {
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        $stmt->close();
        exit;
    }

    // 处理白名单开关
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_whitelist') {
        $status = $_POST['status']; // 1 为启用，0 为关闭
        $update_sql = "UPDATE huaidansetting SET kq_domain = ? WHERE gb_domain = 'whitelist_enabled'";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("s", $status);
        if ($stmt->execute()) {
            echo json_encode(['code' => 0, 'msg' => '操作成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        $stmt->close();
        exit;
    }

    // 处理列表请求
    if (isset($_GET['action']) && $_GET['action'] === 'list') {
        $sql = "SELECT main_domain FROM huaidanbmd";
        $result = $conn->query($sql);
        $domains = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $domains[] = ['main_domain' => $row['main_domain']];
            }
        }
        echo json_encode([
            'code' => 0,
            'msg' => '',
            'count' => count($domains),
            'data' => $domains
        ]);
        $conn->close();
        exit;
    }

    // 获取白名单开关状态
    if (isset($_GET['action']) && $_GET['action'] === 'get_whitelist_status') {
        $sql = "SELECT kq_domain FROM huaidansetting WHERE gb_domain = 'whitelist_enabled'";
        $result = $conn->query($sql);
        $status = $result->fetch_assoc()['kq_domain'];
        echo json_encode(['code' => 0, 'status' => $status]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>秋泽后台</title>  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/css/layui.css">
     <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            padding: 20px;
        }
        .layui-card {
            margin-bottom: 20px;
        }
        .button-group {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: flex-start;
        }
        .button-group .layui-btn {
            min-width: 80px;
        }
        @media screen and (max-width: 768px) {
            .button-group {
                justify-content: center;
            }
            .button-group .layui-btn {
                min-width: 70px;
                font-size: 12px;
                padding: 0 10px;
            }
        }
    </style>
</head>
<body>
<div class="layui-container">
    <div class="layui-card">
        <div class="layui-card-header">添加白名单主域名 (欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" id="addForm">
                <div class="layui-form-item">
                    <label class="layui-form-label">主域名</label>
                    <div class="layui-input-block">
                        <input type="text" name="main_domain" required lay-verify="required" placeholder="输入域名" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <div class="button-group">
                            <button type="button" class="layui-btn layui-btn-normal" id="enableWhitelist">启用白名单</button>
                            <button type="button" class="layui-btn layui-btn-warm" id="disableWhitelist">关闭白名单</button>
                            <button class="layui-btn" lay-submit lay-filter="addDomain">立即添加</button>
                            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="layui-card">
        <div class="layui-card-header">白名单列表</div>
        <div class="layui-card-body">
            <table class="layui-table" lay-data="{url:'admin.php?action=list', page:true, id:'domainTable'}" lay-filter="domainTable">
                <thead>
                    <tr>
                        <th lay-data="{field:'main_domain', width:300}">已经添加的</th>
                        <th lay-data="{fixed:'right', width:150, align:'center', toolbar:'#barDemo'}">操作</th>
                    </tr>
                </thead>
            </table>
            <script type="text/html" id="barDemo">
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="delete">删除</a>
            </script>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/layui@2.8.18/dist/layui.js"></script>
<script>
layui.use(['form', 'table', 'layer'], function(){
    var form = layui.form;
    var table = layui.table;
    var layer = layui.layer;
    var $ = layui.$;

    // 获取初始白名单状态并更新按钮样式
    $.get('admin.php?action=get_whitelist_status', function(res) {
        if (res.code === 0) {
            updateButtonStyles(res.status);
        }
    }, 'json');

    // 启用白名单
    $('#enableWhitelist').click(function(){
        $.post('admin.php', {action: 'toggle_whitelist', status: '1'}, function(res) {
            if (res.code === 0) {
                layer.msg('白名单已启用', {icon: 1});
                updateButtonStyles('1');
            } else {
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
    });

    // 关闭白名单
    $('#disableWhitelist').click(function(){
        $.post('admin.php', {action: 'toggle_whitelist', status: '0'}, function(res) {
            if (res.code === 0) {
                layer.msg('白名单已关闭', {icon: 1});
                updateButtonStyles('0');
            } else {
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
    });

    // 更新按钮样式
    function updateButtonStyles(status) {
        if (status === '1') {
            $('#enableWhitelist').addClass('layui-btn-disabled').prop('disabled', true);
            $('#disableWhitelist').removeClass('layui-btn-disabled').prop('disabled', false);
        } else {
            $('#enableWhitelist').removeClass('layui-btn-disabled').prop('disabled', false);
            $('#disableWhitelist').addClass('layui-btn-disabled').prop('disabled', true);
        }
    }

    // 添加域名
    form.on('submit(addDomain)', function(data){
        $.ajax({
            url: 'admin.php',
            type: 'POST',
            data: {
                action: 'add',
                main_domain: data.field.main_domain
            },
            dataType: 'json',
            success: function(res) {
                if (res.code === 0) {
                    layer.msg(res.msg, {icon: 1});
                    table.reload('domainTable');
                    $('#addForm')[0].reset();
                } else {
                    layer.msg(res.msg, {icon: 2});
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                layer.msg('请求失败: ' + textStatus, {icon: 2});
                console.error('添加请求错误:', textStatus, errorThrown, jqXHR.responseText);
            }
        });
        return false;
    });

    // 删除域名
    table.on('tool(domainTable)', function(obj){
        var data = obj.data;
        if (obj.event === 'delete') {
            layer.confirm('确定删除域名 ' + data.main_domain + ' 吗？', {
                btn: ['确定', '取消']
            }, function(){
                $.ajax({
                    url: 'admin.php',
                    type: 'POST',
                    data: {
                        action: 'delete',
                        main_domain: data.main_domain
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.code === 0) {
                            layer.msg(res.msg, {icon: 1});
                            obj.del();
                        } else {
                            layer.msg(res.msg, {icon: 2});
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        layer.msg('请求失败: ' + textStatus, {icon: 2});
                        console.error('删除请求错误:', textStatus, errorThrown, jqXHR.responseText);
                    }
                });
            });
        }
    });
});
</script>
</body>
</html>
