<?php
// 包含数据库配置
include 'config.php';

// 初始化响应
$response = '';

// 检查是否提交了表单
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取POST数据中的URL
    $url = isset($_POST['url']) ? trim($_POST['url']) : '';
    $agree = isset($_POST['agree']) ? $_POST['agree'] : false;
    
    // 检查用户是否同意条款
    if (!$agree) {
        echo '请先同意并勾选生成服务使用守则';
        exit;
    }
    
    // 检查URL是否有效且使用HTTP/HTTPS协议
    if (empty($url) || !preg_match('/^https?:\/\//i', $url)) {
        echo '链接仅支持HTTP/HTTPS协议';
        exit;
    }
    
    // 从URL中提取域名
    $parsed_url = parse_url($url);
    $domain = isset($parsed_url['host']) ? $parsed_url['host'] : '';
    
    // 去除'www.'前缀
    $domain = preg_replace('/^www\./i', '', $domain);
    
    if (empty($domain)) {
        echo '无效的域名';
        exit;
    }
    
    // 连接数据库
    try {
        $pdo = new PDO("mysql:host={$db_host};dbname={$db_name}", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // 检查白名单开关状态
        $stmt = $pdo->prepare("SELECT kq_domain FROM huaidansetting WHERE gb_domain = 'whitelist_enabled'");
        $stmt->execute();
        $whitelist_enabled = $stmt->fetchColumn();

        if ($whitelist_enabled === '0') {
            // 白名单关闭，直接返回成功
            echo 'success';
        } else {
            // 白名单启用，检查域名是否在白名单中
            $stmt = $pdo->prepare("SELECT main_domain FROM huaidanbmd");
            $stmt->execute();
            $whitelisted_domains = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $is_valid = false;
            foreach ($whitelisted_domains as $main_domain) {
                if (strtolower($domain) === strtolower($main_domain)) {
                    $is_valid = true;
                    break;
                }
                if (preg_match('/^([a-z0-9-]+\.)*' . preg_quote($main_domain, '/') . '$/i', $domain)) {
                    $is_valid = true;
                    break;
                }
            }
            
            if ($is_valid) {
                echo 'success';
            } else {
                echo '<script>alert("请联系秋泽添加白名单");</script>请联系秋泽添加白名单';
            }
        }
    } catch (PDOException $e) {
        error_log("数据库错误: " . $e->getMessage());
        echo '系统错误，请稍后再试';
    }
} else {
    echo '无效的请求方式';
}
?>
