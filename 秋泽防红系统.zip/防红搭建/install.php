<?php
// 初始化错误信息
$errorMessage = "";
// 用于存储成功信息
$successMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 固定数据库主机为 localhost
    $db_host = 'localhost';
    // 获取用户输入的数据库信息
    $db_user = trim($_POST['db_user']);
    $db_pass = trim($_POST['db_pass']);
    $db_name = trim($_POST['db_name']);

    // 检查必填字段是否为空
    if (empty($db_user) || empty($db_pass) || empty($db_name)) {
        $errorMessage = "数据库用户名、密码和数据库名称均为必填项，请填写完整。";
    } else {
        // 创建数据库连接
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        if ($conn->connect_error) {
            // 连接失败，设置错误信息
            $errorMessage = "连接数据库失败: ". $conn->connect_error;
        } else {
            // 创建 hd_records 表的SQL语句
            $sqlHdRecords = "CREATE TABLE IF NOT EXISTS `hd_records` (
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `hd_old` varchar(255) NOT NULL,
                                `hd_new` varchar(255) NOT NULL,
                                `mode` varchar(50) NOT NULL,
                                `customer` varchar(50) NOT NULL,
                                `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                                PRIMARY KEY (`id`)
                            ) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;";
            if ($conn->query($sqlHdRecords) === TRUE) {
                // 创建 huaidanbmd 表的SQL语句，修改字符集为utf8
                $sqlHuaidanbmd = "CREATE TABLE IF NOT EXISTS `huaidanbmd` (
                                    `id` int(11) NOT NULL AUTO_INCREMENT,
                                    `main_domain` varchar(255) NOT NULL,
                                    PRIMARY KEY (`id`),
                                    UNIQUE KEY `main_domain` (`main_domain`)
                                ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;";
                if ($conn->query($sqlHuaidanbmd) === TRUE) {
                    // 创建 huaidansetting 表的SQL语句
                    $sqlHuaidansetting = "CREATE TABLE IF NOT EXISTS `huaidansetting` (
                                            `id` int(11) NOT NULL AUTO_INCREMENT,
                                            `gb_domain` varchar(50) NOT NULL,
                                            `kq_domain` varchar(50) NOT NULL,
                                            PRIMARY KEY (`id`)
                                        ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;";
                    if ($conn->query($sqlHuaidansetting) === TRUE) {
                        // 创建 login 表的SQL语句
                        $sqlLogin = "CREATE TABLE IF NOT EXISTS `login` (
                                        `id` int(11) NOT NULL AUTO_INCREMENT,
                                        `username` varchar(50) NOT NULL,
                                        `password` varchar(255) NOT NULL,
                                        PRIMARY KEY (`id`),
                                        UNIQUE KEY `username` (`username`)
                                    ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;";
                        if ($conn->query($sqlLogin) === TRUE) {
                            // 插入 login 表的默认数据
                            $defaultLogin = [
                                ['username' => '@QZNB886688', 'password' => 'e10adc3949ba59abbe56e057f20f883e']
                            ];
                            foreach ($defaultLogin as $login) {
                                $insertLoginSql = "INSERT INTO `login` (username, password) VALUES (?,?)";
                                $stmt = $conn->prepare($insertLoginSql);
                                $stmt->bind_param("ss", $login['username'], $login['password']);
                                $stmt->execute();
                                $stmt->close();
                            }

                            // 表创建成功，设置成功提示信息
                            $successMessage = "安装成功 后台/QZNB0813 账号密码 @QZNB886688 123456 有问题联系TG@QZNB886688  ";
                        } else {
                            // login 表创建失败，设置错误信息
                            $errorMessage = "创建 login 表时出错: ". $conn->error;
                        }
                    } else {
                        // huaidansetting 表创建失败，设置错误信息
                        $errorMessage = "创建 huaidansetting 表时出错: ". $conn->error;
                    }
                } else {
                    // huaidanbmd 表创建失败，设置错误信息
                    $errorMessage = "创建 huaidanbmd 表时出错: ". $conn->error;
                }
            } else {
                // hd_records 表创建失败，设置错误信息
                $errorMessage = "创建 hd_records 表时出错: ". $conn->error;
            }
            // 关闭数据库连接
            $conn->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>数据库设置</title>
    <link rel="shortcut icon" href="https://i.hd-r.icu/e3b62a6d565c1e7080fc19707ac2dac2.jpg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">     <link rel="stylesheet" href="/css/1layui.css"/>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        :root {
            --primary-color: #C5C1FF;
            --hover-color: #C5C1FF;
            --text-color: #1a1a1a;
            --border-color: #e5e7eb;
            --background-color: #f0f0f0;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: var(--text-color);
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-color: var(--background-color);
        }

       .container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

       .form-header {
            text-align: center;
            margin-bottom: 20px;
        }

       .form-header i {
            font-size: 48px;
            background: linear-gradient(-225deg, #2CD8D5 0%, #C5C1FF 56%, #FFBAC3 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
            display: inline-block;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-8px);
            }
        }

       .form-header h1 {
            font-size: 24px;
            color: var(--text-color);
            margin-bottom: 4px;
            font-weight: 600;
        }

       .form-group {
            margin-bottom: 16px;
        }

       .form-group label {
            display: block;
            margin-bottom: 6px;
            color: var(--text-color);
            font-weight: 500;
            font-size: 14px;
        }

       .input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

       .input-wrapper i {
            position: absolute;
            left: 12px;
            color: #6b7280;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 12px 12px 36px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #fafafa;
            appearance: none;
            cursor: pointer;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(197, 193, 255, 0.2);
            background: white;
        }

        input[type="text"]:focus+i,
        input[type="password"]:focus+i {
            color: var(--primary-color);
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background: linear-gradient(-225deg, #2CD8D5 0%, #C5C1FF 56%, #FFBAC3 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        input[type="submit"]:hover {
            transform: translateY(-2px);
        }

        input[type="submit"]:active {
            transform: translateY(0);
        }

        @media (max-width: 480px) {
           .container {
                padding: 16px;
            }

           .form-header i {
                font-size: 40px;
            }

           .form-header h1 {
                font-size: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-header">
            <i class="fas fa-database"></i>
            <h1>数据库设置</h1>
        </div>
        <form method="post">
            <?php if (!empty($errorMessage)):?>
                <div style="color: red;"><?php echo $errorMessage;?></div>
            <?php elseif (!empty($successMessage)):?>
                <div style="color: green;"><?php echo $successMessage;?></div>
            <?php endif;?>
            <div class="form-group">
                <label for="db_user">数据库用户名</label>
                <div class="input-wrapper">
                    <input type="text" name="db_user" id="db_user" placeholder="数据库用户名" required>
                    <i class="fas fa-user"></i>
                </div>
            </div>
            <div class="form-group">
                <label for="db_pass">数据库密码</label>
                <div class="input-wrapper">
                    <input type="password" name="db_pass" id="db_pass" placeholder="数据库密码" required>
                    <i class="fas fa-lock"></i>
                </div>
            </div>
            <div class="form-group">
                <label for="db_name">数据库名称</label>
                <div class="input-wrapper">
                    <input type="text" name="db_name" id="db_name" placeholder="数据库名称" required>
                    <i class="fas fa-database"></i>
                </div>
            </div>
            <input type="submit" value="创建数据库列表" />
        </form>
    </div>
</body>

</html>
